------------------------------------------------------------------
HOLLYWOOD HILLS v1.0, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Hollywood Hills
 - Hollywood Hills, Italic
 - Hollywood Hills, Bold
 - Hollywood Hills, Bold Italic
 - Hollywood Hills Condensed
 - Hollywood Hills Condensed, Italic
 - Hollywood Hills Expanded
 - Hollywood Hills Expanded, Italic

v1.0 FEATURES
------------------------------------------------------------------

 - Includes lowercase and uppercase letters, numbers, and limited
   punctuation.
 - Proper spacing and kerning.


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com